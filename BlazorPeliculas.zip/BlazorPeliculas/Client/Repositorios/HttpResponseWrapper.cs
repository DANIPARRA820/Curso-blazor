﻿using Microsoft.AspNetCore.Components.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace BlazorPeliculas.Client.Repositorios
{
    public class HttpResponseWrapper <T>//se utilizara en la clase repositorio
    {
        public HttpResponseWrapper(T response, bool error, HttpResponseMessage httpResponseMessage)
        {
            Error = error;
            Response = response;
            HttpResponseMessage = httpResponseMessage;
        }

        public bool Error { get; set; }//si hay error
        public T Response { get; set; }//respuesta serializada
        public HttpResponseMessage HttpResponseMessage { get; set; } //respuesta completa deserializada
    }
}

﻿using BlazorPeliculas.Shared.Entidades;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace BlazorPeliculas.Server.Controllers
{
    [ApiController]
    [Route("api/[controller]")] //la ruta del controlador, el controler se reemplazar con el prefijo con el nombre del controlador en 
    //este caso con generos sin el controller
    public class GenerosController: ControllerBase
    {
        //se utilizara injeccion de dependencias para injectar una instancia de la depencia dbcontext en nuestro controlador
        //utilizaremos entityframeworkcore
        private readonly ApplicationDbContext context;
        public GenerosController(ApplicationDbContext context)
        {
            this.context = context;
        }
        [HttpPost]
        public async Task<ActionResult> Post(Genero genero)
        {
            context.Add(genero);
            await context.SaveChangesAsync();
            return Ok();
        
        }
    }
}

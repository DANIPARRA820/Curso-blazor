﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorPeliculas.Client.Helpers
{
    public class UtilidadesString//esta es una clase la cual esta llamando el metodo enmayuscular
    {
        //Metodo que devuelve un string
        //para utilizar este metodo con la clase, solo debo colocarlo publi static y donde lo llamo desde la clase.nombre metodo
        public static string Enmayuscular(string valor) => valor.ToUpper();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorPeliculas.Shared.Entidades
{
    public class GeneroPelicula
    {
        public int PeliculaId { get; set; }
        public int GeneroId { get; set; }
        public Genero Genero { get; set; }//PROPIEDAD DE NAVEGACION 
        public Pelicula Pelicula { get; set; }//PROPIEDAD DE NAVEGACION
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BlazorPeliculas.Shared.Entidades
{
    public class Persona
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="El campo {0} es obligatorio")]
        public string Nombre {get;set;}
        public string Biografia { get; set; }
        public string Foto { get; set; }
        [Required (ErrorMessage ="El campo {1} es obligatorio")] 
        public DateTime? FechaNacimiento { get; set; }
        public List<PeliculaActor> PeliculasActor { get; set; }
        public override bool Equals(object obj)
        {
            if (obj is Persona P2) 
            {
                return Id == P2.Id;
            }
            return false;
        }
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

    }
}

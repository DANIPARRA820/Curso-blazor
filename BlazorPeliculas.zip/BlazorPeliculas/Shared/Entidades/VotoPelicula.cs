﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorPeliculas.Shared.Entidades
{
    public class VotoPelicula
    {
        public int Id { get; set; }
        public int Voto { get; set; }
        public DateTime FechaVoto { get; set; }
        public int PeliculaId { get; set; }//Entidad que va ser una llave foranea que va a apuntar hacia la tabla de peliculas
        public Pelicula Pelicula { get; set; }
    }
}

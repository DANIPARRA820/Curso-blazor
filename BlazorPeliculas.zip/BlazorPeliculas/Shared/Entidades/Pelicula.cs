﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BlazorPeliculas.Shared.Entidades
{
    public class Pelicula
    {
        public int Id { get; set; }
        [Required]
        public string Titulo { get; set; }
        public string Resumen { get; set; }
        public bool EnCartelera { get; set; }
        public string Trailer { get; set; }
        [Required]
        public DateTime? Lanzamiento { get; set; }
        public string Poster { get; set; }//va a contener la url del poster de la pelicula
        public List<GeneroPelicula> GenerosPelicula { get; set; } = new List<GeneroPelicula>();
        public List<PeliculaActor> PeliculasActor { get; set; }
        public string TituloCortado
        {
            get { if (string.IsNullOrWhiteSpace(Titulo))
                    {
                        return null;
                    }
                    if (Titulo.Length > 60) //si el titulo tiene mas de 60 caracteres lo recorta para que no afecte el diseño de la pag
                    {
                        return Titulo.Substring(0, 60) + "...";
                    }
                    else
                    {
                        return Titulo;
                    }
                 }
        }
    }
}

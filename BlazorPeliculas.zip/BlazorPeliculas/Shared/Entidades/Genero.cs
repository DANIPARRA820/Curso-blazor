﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace BlazorPeliculas.Shared.Entidades
{
   public class Genero
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="El Campo {0} es obligatorio")]
        public string Nombre { get; set; }
        //Establecer la relacion entre genero y generopelicula, se debe de modelar con una lista o coleccion
        public List<GeneroPelicula> GeneroPeliculas { get; set; }
    }
}
